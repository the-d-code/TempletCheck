﻿using System;
using System.Collections.Generic;

namespace loan.Models;

public partial class LoanTable
{
    public int LoanId { get; set; }

    public string CustomerName { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public double PrincipleAmount { get; set; }

    public double NoOfYear { get; set; }

    public double IntrestRate { get; set; }

    public double IntrestAmount { get; set; }
}
