﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace loan.Models;

public partial class LoneContext : DbContext
{
    public LoneContext()
    {
    }

    public LoneContext(DbContextOptions<LoneContext> options)
        : base(options)
    {
    }

    public virtual DbSet<LoanTable> LoanTables { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=Kenil\\SQLEXPRESS;Initial Catalog=lone;Integrated Security=True;Trust Server Certificate=True;Trusted_Connection=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<LoanTable>(entity =>
        {
            entity.HasKey(e => e.LoanId);

            entity.ToTable("loan_Table");

            entity.Property(e => e.LoanId).HasColumnName("loanId");
            entity.Property(e => e.CustomerName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("customerName");
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("gender");
            entity.Property(e => e.IntrestAmount).HasColumnName("intrestAmount");
            entity.Property(e => e.IntrestRate).HasColumnName("intrestRate");
            entity.Property(e => e.NoOfYear).HasColumnName("noOfYear");
            entity.Property(e => e.PrincipleAmount).HasColumnName("principleAmount");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
