﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using loan.Models;
using Newtonsoft.Json;
using System.Diagnostics;

namespace loan.Controllers
{
    public class LoanTablesController : Controller
    {
        private readonly LoneContext _context;
        private string apiUrl = @"https://localhost:7257/api/Loan";
        private HttpClient _httpClient;

        public LoanTablesController(LoneContext context)
        {
            _context = context;
            _httpClient = new HttpClient();
        }

        // GET: LoanTables
        public async Task<IActionResult> Index()
        {
            return View(await _context.LoanTables.ToListAsync());
        }

        // GET: LoanTables/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loanTable = await _context.LoanTables
                .FirstOrDefaultAsync(m => m.LoanId == id);
            if (loanTable == null)
            {
                return NotFound();
            }

            return View(loanTable);
        }

        // GET: LoanTables/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: LoanTables/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerName,Gender,PrincipleAmount,NoOfYear")] LoanTable loanTable)
        {
            var respons = await _httpClient.GetAsync(apiUrl + $"?gender={loanTable.Gender}&principalAmount={loanTable.PrincipleAmount}&noOfYears={loanTable.NoOfYear}");
            string result = await respons.Content.ReadAsStringAsync();
            dynamic d = JsonConvert.DeserializeObject(result);
            loanTable.IntrestRate = d.interestRate;
            loanTable.IntrestAmount = d.interestAmount;
            Debug.WriteLine(loanTable.CustomerName);
            if (ModelState.IsValid) 
            {
                _context.Add(loanTable);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(loanTable);
        }

        // GET: LoanTables/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loanTable = await _context.LoanTables.FindAsync(id);
            if (loanTable == null)
            {
                return NotFound();
            }
            return View(loanTable);
        }

        // POST: LoanTables/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("LoanId,CustomerName,Gender,PrincipleAmount,NoOfYear,IntrestRate,IntrestAmount")] LoanTable loanTable)
        {
            if (id != loanTable.LoanId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(loanTable);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LoanTableExists(loanTable.LoanId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(loanTable);
        }

        // GET: LoanTables/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var loanTable = await _context.LoanTables
                .FirstOrDefaultAsync(m => m.LoanId == id);
            if (loanTable == null)
            {
                return NotFound();
            }

            return View(loanTable);
        }

        // POST: LoanTables/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var loanTable = await _context.LoanTables.FindAsync(id);
            if (loanTable != null)
            {
                _context.LoanTables.Remove(loanTable);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LoanTableExists(int id)
        {
            return _context.LoanTables.Any(e => e.LoanId == id);
        }
    }
}
