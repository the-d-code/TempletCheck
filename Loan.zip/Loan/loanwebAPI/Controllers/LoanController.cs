﻿using loanwebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace loanwebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        [HttpGet]
        public IActionResult getInterestAmount([FromQuery] loan data)
        {
            double interestAmount;
            double interestRate = 0.1;
            if (data.gender == "Female")
            {
                interestRate = 0.09;
            }
            interestAmount = (data.principalAmount * interestRate * data.noOfYears);
            Debug.WriteLine(interestAmount);
            var d = new { interestAmount = interestAmount, interestRate = interestRate };
            return new JsonResult(d);
        }
    }
}
