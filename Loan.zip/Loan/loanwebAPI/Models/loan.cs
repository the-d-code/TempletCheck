﻿namespace loanwebAPI.Models
{
    public class loan
    {
        public string gender { get; set; }
        public double principalAmount { get; set; }
        public int noOfYears { get; set; }

    }
}
