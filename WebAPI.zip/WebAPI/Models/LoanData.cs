﻿namespace WebAPI.Models
{
    public class LoanData
    {
        public string gender { get; set; }
        public double principalAmount { get; set; }
        public int noOfYears{ get; set; }

    }
}
