﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanController : ControllerBase
    {
        [HttpGet]
        public IActionResult getInterestAmount([FromQuery] LoanData data)
        {
            double interestAmount;
            double interestRate = 0.1;
            if (data.gender == "Female")
            {
                interestRate = 0.09;
            }

            interestAmount = (data.principalAmount * data.noOfYears * interestRate);
            var d = new { interestAmount = interestAmount, interestRate = interestRate };
            return new JsonResult(d);
        }
    }
}
