﻿using System;
using System.Collections.Generic;

namespace MVC_Prc1.Models
{
    public partial class Teacher
    {
        public int Tid { get; set; }
        public string Tname { get; set; } = null!;
    }
}
