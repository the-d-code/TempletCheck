﻿namespace MVC_API___Prc1.Models
{
    public class Teacher
    {
        public int tid { get; set; }
        public string tname { get; set; }
    }
}
