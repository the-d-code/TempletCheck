using System;
					
public class Program
{
	public static void Main()
	{
		var p=(Id:1, FirstName:"AAA", LastName: "Shah");
		Console.WriteLine($"{p.Id} {p.FirstName} {p.LastName}");
	}
}