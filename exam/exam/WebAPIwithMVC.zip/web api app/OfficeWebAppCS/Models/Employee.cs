﻿namespace OfficeWebAppCS.Models
{
    [Serializable]
    public class Employee
    {
        public int empID { get; set; }
        public string empName { get; set; }
        public string designation { get; set; }

    }
}
