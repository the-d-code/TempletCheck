﻿using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OfficeWebAppCS.Models;

namespace OfficeWebAppCS.Controllers
{
    public class EmployeesController : Controller
    {
        private string baseURL = "http://localhost:5084/api/employees/";
        private HttpClient client = new HttpClient();


        // GET: EmployeesController
        public async Task<ActionResult> Index()
        {

            var employees = new List<Employee>();
            if (TempData["emps"] is null)
            {


                var response = await client.GetAsync(baseURL);
                var resString = await response.Content.ReadAsStringAsync();
                employees = JsonConvert.DeserializeObject<List<Employee>>(resString);
            } else
            {
                employees = JsonConvert.DeserializeObject<List<Employee>>(TempData["emps"] as string);
            }
            return View(employees);
        }

        // GET: EmployeesController/Details/5
        public async Task<ActionResult> Details(int id)
        {
            //var response = await client.GetAsync(baseURL + "/" + id.ToString());
            //var resString = await response.Content.ReadAsStringAsync();
            //var employee = JsonConvert.DeserializeObject<Employee>(resString);

            return View(await GetEmpByID(id));
        }

        public async Task<Employee> GetEmpByID(int id)
        {
            string appURL = baseURL+id.ToString();
            var response = await client.GetAsync(appURL);
            var resString = await response.Content.ReadAsStringAsync();
            var employee = JsonConvert.DeserializeObject<Employee>(resString);

            return employee;
        }

        // GET: EmployeesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Employee newEmployee)
        {
            try
            {
                var objData = JsonConvert.SerializeObject(newEmployee);

                StringContent content = new StringContent(objData, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(baseURL, content);

                return RedirectToAction("Index","Employees");
            }
            catch
            {
                return View();
            }
        }


        public ActionResult SearchEmp()
        {
            return View();
        }

        // POST: EmployeesController/SearchEmp
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SearchEmp(string designation)
        {
            try
            {
                var response = await client.GetAsync(baseURL+"designation/"+designation);
                var resString = await response.Content.ReadAsStringAsync();
                var employees = JsonConvert.DeserializeObject<List<Employee>>(resString);

                TempData["emps"] = JsonConvert.SerializeObject(employees);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            return View(await GetEmpByID(id));
        }

        // POST: EmployeesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, Employee updatedEmployee)
        {
            try
            {
                var objData = JsonConvert.SerializeObject(updatedEmployee);

                StringContent content = new StringContent(objData, Encoding.UTF8, "application/json");
                var response = await client.PutAsync(baseURL + id.ToString(), content);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            return View();
        }

        // POST: EmployeesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
