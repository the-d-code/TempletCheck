﻿using Microsoft.AspNetCore.Mvc;
using ProductManagementAPICS.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductManagementAPICS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private static List<Product> Products = new List<Product>();


        public ProductController() {
            if (Products.Count < 1)
            {
                Products.Add(new Product 
                {
                    ProductId = 1,ProductName = "Desk", 
                    ProductDescription = "wodden" , 
                    Rate = 200
                });
                Products.Add(new Product
                {
                    ProductId = 2,
                    ProductName = "chair",
                    ProductDescription =
                    "wodden",
                    Rate = 500
                });
                Products.Add(new Product
                {
                    ProductId = 3,
                    ProductName = "Table",
                    ProductDescription =
                    "wodden",
                    Rate = 300
                });
                Products.Add(new Product
                {
                    ProductId = 4,
                    ProductName = "Decore",
                    ProductDescription =
                   "wodden",
                    Rate = 800
                });
            }
        }
        // GET: api/<ProductController>
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return Products.ToList();
        }

        // GET api/<ProductController>/5
        [HttpGet("{id}")]
        public  Product Get(int id) 
        {
            return Products.SingleOrDefault(p => p.ProductId == id) ;
        }

        // POST api/<ProductController>
        [HttpPost]
        public void Post([FromBody] Product product)
        {
            if (product != null)
            {
                Products.Add(product);
               Ok("Data inserted...");
            }
            else
            {
                BadRequest("Error in inserting Data...");
            }
        }
           
            

        // PUT api/<ProductController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            if (id != null)
            {
                var productId = Products.FirstOrDefault(p => p.ProductId == id);
                Products.Remove(productId);
            }
           
        }
    }
}
