﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace matrix
{
    class MatrixOperations<T>
    {
        public static T[,] Add(T[,] matrix1, T[,] matrix2)
        {
            int rows = matrix1.GetLength(0);
            int columns = matrix1.GetLength(1);

            T[,] result = new T[rows, columns];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    dynamic value1 = matrix1[i, j];
                    dynamic value2 = matrix2[i, j];
                    result[i, j] = value1 + value2;
                }
            }

            return result;
        }

        public static T[,] Subtract(T[,] matrix1, T[,] matrix2)
        {
            int rows = matrix1.GetLength(0);
            int columns = matrix1.GetLength(1);

            T[,] result = new T[rows, columns];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    dynamic value1 = matrix1[i, j];
                    dynamic value2 = matrix2[i, j];
                    result[i, j] = value1 - value2;
                }
            }

            return result;
        }

        public static T[,] Multiply(T[,] matrix1, T[,] matrix2)
        {
            int rows1 = matrix1.GetLength(0);
            int columns1 = matrix1.GetLength(1);
            int rows2 = matrix2.GetLength(0);
            int columns2 = matrix2.GetLength(1);

            if (columns1 != rows2)
            {
                throw new ArgumentException("Invalid matrix multiplication. Number of columns in the first matrix must be equal to the number of rows in the second matrix.");
            }

            T[,] result = new T[rows1, columns2];

            for (int i = 0; i < rows1; i++)
            {
                for (int j = 0; j < columns2; j++)
                {
                    result[i, j] = default(T);

                    for (int k = 0; k < columns1; k++)
                    {
                        dynamic value1 = matrix1[i, k];
                        dynamic value2 = matrix2[k, j];
                        result[i, j] += value1 * value2;
                    }
                }
            }

            return result;
        }

        public static T[,] Divide(T[,] matrix, T divisor)
        {
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            T[,] result = new T[rows, columns];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    dynamic value = matrix[i, j];
                    result[i, j] = value / divisor;
                }
            }

            return result;
        }
    }

}
