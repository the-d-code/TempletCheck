﻿using System;

namespace matrix
{
    class Program
    {
        static void Main()
        {
            // Example usage
            int[,] matrix1 = { { 1, 2 }, { 3, 4 } };
            int[,] matrix2 = { { 5, 6 }, { 7, 8 } };

            Console.WriteLine("Matrix Addition:");
            PrintMatrix(MatrixOperations<int>.Add(matrix1, matrix2));

            Console.WriteLine("\nMatrix Subtraction:");
            PrintMatrix(MatrixOperations<int>.Subtract(matrix1, matrix2));

            Console.WriteLine("\nMatrix Multiplication:");
            PrintMatrix(MatrixOperations<int>.Multiply(matrix1, matrix2));

            Console.WriteLine("\nMatrix Division:");
            PrintMatrix(MatrixOperations<int>.Divide(matrix1, 2));
        }

        static void PrintMatrix<T>(T[,] matrix)
        {
            int rows = matrix.GetLength(0);
            int columns = matrix.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
